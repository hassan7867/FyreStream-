<div class="footer">
        	<div class="container">
            	<div class="footer-row">
                	<div class="ft-menu">
                    	<ul>
                        	<li><a href="#">About Fyrestream</a></li>
                            <li><a href="#">Help</a></li>
                            <li><a href="#">Terms of Use</a></li>
                            <li><a href="#">Privacy Policy</a></li>
                            <li><a href="#">Cookies</a></li>
                            <li class="last"><a href="#">Advertising</a></li>
                        </ul>
                    </div>
                    
                    <ul class="store">
                    	<li><a href="#"><img src="/web/images/app-store.png" class="store img-responsive"></a></li>
                        <li class="last"><a href="#"><img src="/web/images/play-store.png" class="store img-responsive"></a></li>
                    </ul><div class="clear"></div>
                    <p>Copyright © 2020 fyrestream All Rights Reserved</p>
                </div>
            </div>
        </div>