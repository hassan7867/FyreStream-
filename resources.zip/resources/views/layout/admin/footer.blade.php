<footer class="main-footer">
    <strong>Copyright &copy; 2014-2020 <a href="http://adminlte.io"></a>.</strong>
    
    <div class="float-right d-none d-sm-inline-block">
    </div>
  </footer>